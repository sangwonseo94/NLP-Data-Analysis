import numpy as np
import re
from flask import Flask, render_template, request, redirect, url_for, session, make_response, jsonify
from service.model import selectLogin, searchJob, signUp, dataMod, matchJob, matchView, jobFlow, updateRating, ratingAvg, candiMatch, compRating
import os

def Userdata_to_Textfile(UserData):
    Result_UserData =""
    UserData_list = UserData.split(" ")
    for UserData_arr in UserData_list:
        Result_UserData += UserData_arr + "\n"
    return Result_UserData

def createApp():
    app = Flask(__name__)
    app.secret_key = 'sdgddsgjhgfkhmrtjhrtgwety47y6u5erbr'
    initRoute( app )
    return app

def initRoute(app):
    @app.route('/')
    def home():
        resp = make_response(render_template('index.html'))
        return resp
    
    @app.route('/Get_User_Text' , methods=['GET'])
    def Get_User_Text():
        if request.method =='GET' :
            
            UserData = request.args.get('content')
          
            save_path = "C:\시험용.txt"
            with open(save_path, "w") as save_part:
                save_part.write(Userdata_to_Textfile(UserData))
           

            #### model을 거친 load_path 파일 ####
            
            load_path = "C:\시험용.txt"
            
            with open(load_path, "r") as load_part:
                Result = load_part.read()
        

        else:
            print("read/ write error")
        return render_template('result.html',Result = Result)